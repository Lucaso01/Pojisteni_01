/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cz.itnetwork.evidencepojisteni;



import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Lukas Skokan
 */
//metody pro komunikaci s uživatelem//
public class Evidence {
    private Databaze databaze;
    private Scanner sc = new Scanner(System.in, "Windows-1250");

    public Evidence() {
        databaze = new Databaze();  
    }
    public void pridejPojistenec() {
    System.out.println("Zadejte jméno:");
    String text = sc.nextLine();
    System.out.println("Zadejte příjmení:");
    String text1 = sc.nextLine();
    System.out.println("Zadejte věk:");
    int vek = Integer.parseInt(sc.nextLine());
    System.out.println("Zadejte číslo:");
    String text3 = sc.nextLine();
    databaze.pridejPojistenec(text, text1, vek, text3);
    }
   
    //Výpis záznamů    
    public void vypisPojistenec() {
        // Zadání data uživatelem     
    ArrayList<Pojistenec> pojistenci = databaze.najdiPojistenci();
       if (pojistenci.size() > 0) {
            System.out.println("Nalezeny tyto pojištěnci: ");
            for (Pojistenec z : pojistenci) {
                System.out.println(z);
            }
        } else {
            // Nenalezeno
            System.out.println("Nebyly nalezeny žádné záznamy."); 
       }
        }
    
    public void vymazPojistenci() {
        System.out.println("Jsou vymazány všechny záznamy");
        databaze.vymazPojistenci();
        }
    
    public void vyhledejPojistence(){
            System.out.println("Zadej jméno:");
            String text = sc.nextLine();
            System.out.println("Zadej příjmení:");
            String text1 = sc.nextLine();
            databaze.najdiPojistence(text, text1);
    ArrayList<Pojistenec> pojistenci = databaze.najdiPojistence(text, text1);
        if (pojistenci.size() > 0) {
            System.out.println("Nalezeny tyto pojištěnci: ");
            for (Pojistenec z : pojistenci) {
                System.out.println(z);
            }
        } else {
            // Nenalezeno
            System.out.println("Nebyly nalezeny žádné záznamy.");
        }
     }
     public void vypisUvodniObrazovku() {
        System.out.println();
        System.out.println();
        System.out.println("-----------------------------\nEvidence pojištěných");
        System.out.println("-----------------------------");
 }
    }
     

     