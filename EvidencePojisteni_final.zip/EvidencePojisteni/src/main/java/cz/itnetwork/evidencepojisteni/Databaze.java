/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cz.itnetwork.evidencepojisteni;
import java.util.ArrayList;
/**
 *
 * @author Lukas Skokan
 */
//vnitřní kolekce pojištenci, která se inicializuje v konstruktoru
public class Databaze {
     private ArrayList<Pojistenec> pojistenci;

    public Databaze() {
        pojistenci = new ArrayList<>();
    }

    public void pridejPojistenec(String jmeno, String prijmeni, int vek, String cislo) {
    pojistenci.add(new Pojistenec(jmeno, prijmeni, vek, cislo));
    }
    public ArrayList<Pojistenec> najdiPojistenci() {
        ArrayList<Pojistenec> nalezene = new ArrayList<>();
        for (Pojistenec z : pojistenci) {
              {
                  nalezene.add(z);
            }
        }
        return nalezene;
    }
    public void vymazPojistenci() {
        ArrayList<Pojistenec> nalezeno = najdiPojistenci();
        for (Pojistenec z : nalezeno) {
            pojistenci.remove(z);
    }
        }
        public ArrayList<Pojistenec> najdiPojistence(String jmeno, String prijmeni) {
            ArrayList<Pojistenec> nalezene = new ArrayList<>();
            for (Pojistenec z : pojistenci){
                if (z.getJmeno().equals(jmeno) && z.getPrijmeni().equals(prijmeni))
                    nalezene.add(z);
                }
        return nalezene;
                    
            }
        }
     
    