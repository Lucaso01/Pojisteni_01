/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package cz.itnetwork.evidencepojisteni;

import java.util.Scanner;



/**
 *
 * @author Lukas Skokan
 */
public class EvidencePojisteni {
// Vytvoření objektu(instance):
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in, "Windows-1250");
         Evidence evidence = new Evidence();
         String volba = "";
    // hlavní cyklus  - výpis možností
    while (!volba.equals("5")) {
        evidence.vypisUvodniObrazovku();
        System.out.println("1 - Přidat nového pojištěnce");
        System.out.println("2 - Vyhledej pojištěnce");
        System.out.println("3 - Výpis pojištěnců");
        System.out.println("4 - Vymazat záznam");
        System.out.println("5 - Konec");
        volba = sc.nextLine();
        System.out.println();
    // reakce na volbu
    switch (volba) {
            case "1":
                evidence.pridejPojistenec();
                break;
             case "2":
                evidence.vyhledejPojistence();
                    break;       
            case "3":
                evidence.vypisPojistenec();
                    break;    
            case "4":
                evidence.vymazPojistenci();
                    break;             
            case "5":
                System.out.println("Libovolnou klávesou ukončíte program...");
                break;
            default:
                System.out.println("Neplatná volba, stiskněte libovolnou klávesu a opakujte volbu.");
                break;
        }
      }      
    }
}
     
   